# COWORK TASK: Deploy OG Images for LinkedIn Social Sharing

## Repository: yellow3.io (GitHub main branch, deployed on Vercel)

## OVERVIEW
Two article pages need OG images for LinkedIn/social media link previews. Two tasks: add image files and update one HTML file.

---

## TASK 1: Add image files to `insights/` folder

Add these two PNG files to the `insights/` directory in the repo:

1. `og-ai-platform-costs.png` (288 KB) - already in this delivery
2. `og-europes-ai-slumber.png` (420 KB) - already in this delivery

Both files are included in this delivery folder at `insights/og-ai-platform-costs.png` and `insights/og-europes-ai-slumber.png`.

---

## TASK 2: Update `europes-ai-slumber.html` - add OG image meta tags

In `insights/europes-ai-slumber.html`, find this line:

```html
    <meta property="og:url" content="https://yellow3.io/insights/europes-ai-slumber">
```

Immediately AFTER it, add these 3 lines:

```html
    <meta property="og:image" content="https://yellow3.io/insights/og-europes-ai-slumber.png">
    <meta property="og:image:width" content="1536">
    <meta property="og:image:height" content="1024">
```

---

## DO NOT TOUCH
- `ai-platform-costs-2026.html` (already has og:image tags with correct path and dimensions)
- `index.html`
- Any other files in the repo
- The logo
- Any CSS or content

---

## VERIFICATION AFTER DEPLOY
1. Confirm both images return 200 OK:
   - https://yellow3.io/insights/og-ai-platform-costs.png
   - https://yellow3.io/insights/og-europes-ai-slumber.png
2. Test both articles at https://www.linkedin.com/post-inspector/:
   - https://yellow3.io/insights/ai-platform-costs-2026
   - https://yellow3.io/insights/europes-ai-slumber
   Both should show the custom OG image in the preview card.
