# TASK: Deploy yellow3 CMS, logo, and fix OG images

## Context
You are working on the `BossyT/yellow3-lab` GitHub repo. This is a static HTML site deployed on Vercel (auto-deploys from `main` branch). The site is live at yellow3.io.

## Your tasks (in order)

### 1. Add `logo.png` to the repo root
Upload the file `logo.png` (provided alongside this brief) to the root of the repo. This is the original yellow3 wordmark - black on white. Do NOT modify, resize, compress, or regenerate this file in any way.

### 2. Add `admin.html` to the repo root
Upload the file `admin.html` (provided alongside this brief) to the root of the repo. This is a CMS interface that will be accessible at yellow3.io/admin. Do NOT modify this file.

### 3. Add OG images to `insights/` folder
Upload these two image files (provided alongside this brief) to the `insights/` directory:
- `og-ai-platform-costs.png`
- `og-europes-ai-slumber.png`

If files with these names already exist, REPLACE them with the provided versions.

### 4. Fix OG image meta tags in BOTH article HTML files

**In `insights/ai-platform-costs-2026.html`:**

Check the `<head>` section. It should contain these three lines (add them after the `og:url` line if missing, or fix them if the values are wrong):

```html
<meta property="og:image" content="https://yellow3.io/insights/og-ai-platform-costs.png">
<meta property="og:image:width" content="1536">
<meta property="og:image:height" content="1024">
```

IMPORTANT: The width MUST be 1536 and height MUST be 1024. If they say 1200 and 630, change them.

**In `insights/europes-ai-slumber.html`:**

Check the `<head>` section. Add these three lines after the `og:url` line if they don't exist:

```html
<meta property="og:image" content="https://yellow3.io/insights/og-europes-ai-slumber.png">
<meta property="og:image:width" content="1536">
<meta property="og:image:height" content="1024">
```

### 5. Update existing pages to use `/logo.png` instead of base64 logo

The following files currently embed the yellow3 logo as a massive base64 string in their nav `<img>` tag. Replace ONLY the `<img>` tag src inside the nav logo link with `/logo.png`.

Files to update:
- `index.html`
- `insights/index.html`
- `insights/ai-platform-costs-2026.html`
- `insights/europes-ai-slumber.html`

In each file, find the `<a href="/" class="logo">` element in the `<nav>`. Inside it there is an `<img>` tag with a huge `src="data:image/jpeg;base64,..."` attribute. Replace that entire `<img>` tag with:

```html
<img src="/logo.png" alt="yellow3">
```

The surrounding `<a>` tag, CSS classes, and everything else must stay exactly as is.

## DO NOT
- Modify the logo file or OG image files in any way
- Change any CSS
- Change any article body content
- Touch `vercel.json`, `sitemap.xml`, `robots.txt`, `llms.txt`
- Add any new dependencies, build steps, or frameworks
- Rename or reorganize any existing files

## Verification
After all commits, confirm these URLs return 200 (not 404):
1. https://yellow3.io/logo.png
2. https://yellow3.io/admin
3. https://yellow3.io/insights/og-ai-platform-costs.png
4. https://yellow3.io/insights/og-europes-ai-slumber.png

Then confirm the og:image tags are correct by checking:
5. `curl -s https://yellow3.io/insights/ai-platform-costs-2026 | grep "og:image"`
   - Should return the og:image, og:image:width (1536), og:image:height (1024)
6. `curl -s https://yellow3.io/insights/europes-ai-slumber | grep "og:image"`
   - Should return the og:image, og:image:width (1536), og:image:height (1024)

Then confirm logos are no longer base64:
7. `curl -s https://yellow3.io/ | grep "logo.png"` - should find a match
8. `curl -s https://yellow3.io/ | grep "data:image/jpeg;base64"` - should find NO match

## Files provided with this task
- `admin.html` - the CMS page
- `logo.png` - the original yellow3 wordmark
- `og-ai-platform-costs.png` - OG image for the AI costs article
- `og-europes-ai-slumber.png` - OG image for the Europe AI article

## Repo details
- GitHub: `BossyT/yellow3-lab` (public)
- Branch: `main`
- Vercel project: `yellow3`
- Live URL: yellow3.io / www.yellow3.io
